"""Calibrated FRD rotor allocation."""
