import unittest
from dataclasses import replace
from pathlib import Path

import numpy as np

from interfaces.contracts import Metadata
from perception.stereo_depth.geometry import load_nominal_rig
from perception.stereo_depth.pairing import ImageFrame, StereoPair
from perception.visual_odometry.stereo import estimate_stereo_motion, solve_relative, half_scale_rig


class StereoOdometryTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rig = load_nominal_rig(Path(__file__).resolve().parents[2] / 'configs/simulator_settings.json')

    def scene(self):
        rng = np.random.RandomState(7)
        return np.column_stack((rng.uniform(7, 18, 100), rng.uniform(-4, 4, 100), rng.uniform(-3, 3, 100)))

    def test_half_scale_preserves_stereo_metric_geometry(self):
        rig = half_scale_rig(self.rig)
        points = self.scene()
        left, _, visible_left = self.rig.left.project_body(points)
        right, _, visible_right = self.rig.right.project_body(points)
        visible = visible_left & visible_right
        left = (left[visible] + .5) * .5 - .5
        right = (right[visible] + .5) * .5 - .5
        recovered, valid, _ = rig.triangulate_body(left, right)
        self.assertTrue(valid.all())
        np.testing.assert_allclose(recovered, points[visible], atol=1e-10)

    def test_known_body_motion_and_camera_lever_arm(self):
        points = self.scene()
        yaw = .05
        rotation = np.array(((np.cos(yaw), -np.sin(yaw), 0.), (np.sin(yaw), np.cos(yaw), 0.), (0., 0., 1.)))
        displacement = np.array((.25, -.12, .06))
        current = (points - displacement) @ rotation
        uv, _, valid = self.rig.left.project_body(current)
        result, found_rotation, count, p95 = solve_relative(points[valid], uv[valid], self.rig)
        np.testing.assert_allclose(result, displacement, atol=.005)
        np.testing.assert_allclose(found_rotation, rotation, atol=.001)
        self.assertGreater(count, 50)
        self.assertLess(p95, .1)

    def test_outliers_are_rejected_and_collinear_geometry_fails(self):
        points = self.scene()
        uv, _, valid = self.rig.left.project_body(points)
        points, uv = points[valid], uv[valid]
        uv[:20] = np.roll(uv[:20], 7, axis=0)
        _, _, count, p95 = solve_relative(points, uv, self.rig)
        self.assertLess(count, len(points))
        self.assertLess(p95, .1)
        with self.assertRaisesRegex(ValueError, 'degenerate'):
            solve_relative(np.tile((10., 0., 0.), (20, 1)), np.tile((480., 360.), (20, 1)), self.rig)

    def test_untextured_inputs_and_epoch_mismatch_rejected(self):
        image = np.zeros((720, 960, 1), dtype=np.uint8)
        def pair(stamp, epoch=0):
            left = ImageFrame(Metadata(stamp, stamp+.2, epoch, 'left', 'front_left_image'), 'mono8', image)
            right = ImageFrame(Metadata(stamp, stamp+.2, epoch, 'right', 'front_right_image'), 'mono8', image)
            return StereoPair(Metadata(stamp, stamp+.2, epoch, 'pair', 'front_stereo'), left, right, 0.)
        with self.assertRaises(ValueError): estimate_stereo_motion(pair(1.), pair(1.1), self.rig)
        with self.assertRaisesRegex(ValueError, 'epoch or time'): estimate_stereo_motion(pair(1.), pair(1.1, 1), self.rig)
        with self.assertRaisesRegex(ValueError, 'epoch or time'): estimate_stereo_motion(pair(1.), pair(1.), self.rig)

class RefineCorrespondencesTests(unittest.TestCase):
    def test_subpixel_shift_is_recovered_and_blank_image_rejected(self):
        import cv2
        from perception.visual_odometry.stereo import refine_correspondences
        rng = np.random.RandomState(64)
        image = rng.randint(0, 256, (150, 200), dtype=np.uint8)
        shifted = cv2.warpAffine(image, np.float32([[1., 0., 2.4], [0., 1., -.7]]), (200, 150))
        points = np.array([[40., 40.], [80., 90.], [140., 110.]], dtype=np.float32)
        expected = points + (2.4, -.7)
        result, valid = refine_correspondences(image, shifted, points, points + (2., -1.), cv2)
        self.assertGreaterEqual(int(valid.sum()), 1)
        np.testing.assert_allclose(result[valid], expected[valid], atol=.2)
        _, valid = refine_correspondences(np.zeros_like(image), np.zeros_like(image), points, points, cv2)
        self.assertFalse(valid.any())


if __name__ == '__main__':
    unittest.main()
